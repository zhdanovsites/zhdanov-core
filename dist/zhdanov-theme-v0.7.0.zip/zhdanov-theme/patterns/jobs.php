<?php
/**
 * Title: Вакансии (из раздела «Вакансии»)
 * Slug: zhdanov/jobs
 * Categories: zhdanov-services
 * Keywords: вакансии, работа, карьера, команда
 * Viewport Width: 1280
 * Description: Открытые вакансии с зарплатой и кнопкой «Откликнуться».
 */
?>
<!-- wp:group {"align":"full","anchor":"vakansii","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="vakansii" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Работа у нас</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Открытые вакансии</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_job","count":6} /--></div>
<!-- /wp:group -->
