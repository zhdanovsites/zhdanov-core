<?php
/**
 * Title: Форма заявки
 * Slug: zhdanov/form
 * Categories: zhdanov-cta,zhdanov-contacts
 * Keywords: заявка, форма, запись
 * Viewport Width: 1280
 * Description: Форма с согласием на обработку данных. Заявки приходят на почту и в Консоль → Заявки.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"860px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:zhdanov/form {"anchor":"zayavka","title":"Оставьте заявку","message":true} /-->
</div>
<!-- /wp:group -->
