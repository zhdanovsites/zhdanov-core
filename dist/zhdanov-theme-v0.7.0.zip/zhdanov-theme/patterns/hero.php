<?php
/**
 * Title: Первый экран: фото, заголовок, 2 кнопки
 * Slug: zhdanov/hero
 * Categories: zhdanov-hero, featured
 * Keywords: первый экран, обложка, hero, баннер
 * Viewport Width: 1280
 * Description: Большое фото на весь экран, заголовок H1 и две кнопки. Замените фото на своё. Используйте на странице с шаблоном «Лендинг».
 */
?>
<!-- wp:cover {"dimRatio":70,"overlayColor":"contrast","minHeight":82,"minHeightUnit":"svh","contentPosition":"bottom left","isDark":true,"align":"full","className":"zh-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-bottom-left zh-hero" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50);min-height:82svh"><span aria-hidden="true" class="wp-block-cover__background has-contrast-background-color has-background-dim-70 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow","style":{"color":{"text":"#ffffffd9"}}} -->
<p class="is-style-zhdanov-eyebrow has-text-color" style="color:#ffffffd9">Город · с 2010 года</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"style":{"typography":{"lineHeight":"1.02"},"elements":{"link":{"color":{"text":"#ffffff"}}},"color":{"text":"#ffffff"}}} -->
<h1 class="wp-block-heading has-text-color has-link-color" style="color:#ffffff;line-height:1.02">Главная мысль о вас одной строкой</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffffe6"},"typography":{"fontSize":"1.1875rem"}}} -->
<p class="has-text-color" style="color:#ffffffe6;font-size:1.1875rem">Коротко: кому вы помогаете и что человек получит. Одно-два предложения.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--30)"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#kontakty">Записаться</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline","style":{"color":{"text":"#ffffff"}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-text-color wp-element-button" href="#uslugi" style="color:#ffffff">Узнать больше</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->
