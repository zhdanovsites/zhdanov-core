<?php
/**
 * Title: Готовая главная: афиша (зал, театр, школа)
 * Slug: zhdanov/page-home-events
 * Categories: zhdanov-pages
 * Keywords: главная, афиша, концертный зал, театр
 * Viewport Width: 1280
 * Block Types: core/post-content
 * Post Types: page
 * Description: Первый экран, афиша, о нас, новости, вопросы, контакты.
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/events-upcoming"} /-->
<!-- wp:pattern {"slug":"zhdanov/about"} /-->
<!-- wp:pattern {"slug":"zhdanov/news-latest"} /-->
<!-- wp:pattern {"slug":"zhdanov/faq"} /-->
<!-- wp:pattern {"slug":"zhdanov/cta"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
