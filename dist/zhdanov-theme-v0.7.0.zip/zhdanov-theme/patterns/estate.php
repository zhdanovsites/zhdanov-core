<?php
/**
 * Title: Недвижимость (из раздела «Объекты»)
 * Slug: zhdanov/estate
 * Categories: zhdanov-services
 * Keywords: недвижимость, квартиры, новостройки, объекты, застройщик
 * Viewport Width: 1280
 * Description: Карточки объектов с ценой, комнатами и площадью; фильтр на странице раздела.
 */
?>
<!-- wp:group {"align":"full","anchor":"obekty","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="obekty" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Объекты</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Квартиры в продаже</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_estate","count":6} /--></div>
<!-- /wp:group -->
