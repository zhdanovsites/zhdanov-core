<?php
/**
 * Title: Цифры и факты
 * Slug: zhdanov/numbers
 * Categories: zhdanov-about
 * Keywords: цифры, факты, опыт
 * Viewport Width: 1280
 * Description: 3-4 крупные цифры. Только проверяемые факты.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30","top":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"typography":{"fontSize":"clamp(2.5rem, 7vw, 4rem)","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:clamp(2.5rem, 7vw, 4rem);font-weight:700;line-height:1">15</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">лет работы</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"typography":{"fontSize":"clamp(2.5rem, 7vw, 4rem)","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:clamp(2.5rem, 7vw, 4rem);font-weight:700;line-height:1">2 000+</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">учеников и клиентов</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"typography":{"fontSize":"clamp(2.5rem, 7vw, 4rem)","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:clamp(2.5rem, 7vw, 4rem);font-weight:700;line-height:1">120</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">событий в год</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"typography":{"fontSize":"clamp(2.5rem, 7vw, 4rem)","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:clamp(2.5rem, 7vw, 4rem);font-weight:700;line-height:1">4,9</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">средняя оценка на Яндекс Картах</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
