<?php
/**
 * Title: Меню (из раздела «Меню»)
 * Slug: zhdanov/menu
 * Categories: zhdanov-services
 * Keywords: меню, блюда, ресторан, кафе
 * Viewport Width: 1280
 * Description: Блюда по разделам: цена, вес, аллергены. Данные из Консоль → Меню.
 */
?>
<!-- wp:group {"align":"full","anchor":"menu","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="menu" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Меню</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Что попробовать</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_dish","showMoreLink":false} /--></div>
<!-- /wp:group -->
