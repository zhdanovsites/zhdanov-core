<?php
/**
 * Title: Готовая главная: писатель, издательство
 * Slug: zhdanov/page-home-books
 * Categories: zhdanov-pages
 * Keywords: главная, писатель, книги, автор, издательство
 * Viewport Width: 1280
 * Description: Портрет и о себе, книги, встречи с читателями, отзывы, новости, связь.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero-split"} /-->
<!-- wp:pattern {"slug":"zhdanov/books"} /-->
<!-- wp:pattern {"slug":"zhdanov/events-upcoming"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/news-latest"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
