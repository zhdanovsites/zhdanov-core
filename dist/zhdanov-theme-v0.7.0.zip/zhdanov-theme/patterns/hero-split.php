<?php
/**
 * Title: Первый экран: текст слева, фото справа
 * Slug: zhdanov/hero-split
 * Categories: zhdanov-hero, featured
 * Keywords: первый экран, автор, эксперт, коуч
 * Viewport Width: 1280
 * Description: Для эксперта, коуча, артиста: заголовок и кнопки слева, портрет справа. На телефоне фото над текстом.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:media-text {"mediaPosition":"right","mediaType":"image","mediaWidth":46,"isStackedOnMobile":true,"verticalAlignment":"center","imageFill":false,"style":{"spacing":{"blockGap":"var:preset|spacing|40"}}} -->
<div class="wp-block-media-text has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-center" style="grid-template-columns:auto 46%"><div class="wp-block-media-text__content"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Имя Фамилия · профессия</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Помогаю людям получить понятный результат</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"contrast-2","fontSize":"large"} -->
<p class="has-contrast-2-color has-text-color has-large-font-size">Одно предложение о подходе и опыте. Без громких слов, только факты.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#kontakty">Записаться</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#uslugi">Услуги и цены</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div><figure class="wp-block-media-text__media"></figure></div>
<!-- /wp:media-text --></div>
<!-- /wp:group -->
