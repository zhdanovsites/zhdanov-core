<?php
/**
 * Title: Афиша: ближайшие события
 * Slug: zhdanov/events-upcoming
 * Categories: zhdanov-events
 * Keywords: афиша, события, концерты, мероприятия
 * Viewport Width: 1280
 * Description: Список ближайших событий с фильтром по месяцам и кнопкой «Вся афиша». Нужен плагин «Жданов: ядро».
 */
?>
<!-- wp:group {"align":"full","anchor":"afisha","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="afisha" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Афиша</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Ближайшие события</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/events {"count":6,"filters":false,"showMoreLink":true} /--></div>
<!-- /wp:group -->
