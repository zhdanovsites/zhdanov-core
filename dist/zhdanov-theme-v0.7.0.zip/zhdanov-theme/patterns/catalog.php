<?php
/**
 * Title: Каталог (из раздела «Каталог»)
 * Slug: zhdanov/catalog
 * Categories: zhdanov-services,shop
 * Keywords: каталог, товары, магазин
 * Viewport Width: 1280
 * Description: Карточки товаров с ценой и наличием. Данные из Консоль → Каталог.
 */
?>
<!-- wp:group {"align":"full","anchor":"katalog","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="katalog" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Каталог</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Популярное</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_product","count":8} /-->
</div>
<!-- /wp:group -->
