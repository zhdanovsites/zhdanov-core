<?php
/**
 * Title: Готовая главная: ресторан, кафе, кондитерская
 * Slug: zhdanov/page-home-food
 * Categories: zhdanov-pages
 * Keywords: главная, ресторан, кафе, меню, бронь, кондитерская
 * Viewport Width: 1280
 * Description: Первый экран, акции, меню, о нас, отзывы, адреса, бронь стола, контакты.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/promos"} /-->
<!-- wp:pattern {"slug":"zhdanov/menu"} /-->
<!-- wp:pattern {"slug":"zhdanov/about"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/branches"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
