<?php
/**
 * Title: Залы и локации (из раздела «Залы»)
 * Slug: zhdanov/rooms
 * Categories: zhdanov-services
 * Keywords: залы, фотостудия, локации, аренда, коворкинг
 * Viewport Width: 1280
 * Description: Залы с площадью, вместимостью, ценой за час и бронью.
 */
?>
<!-- wp:group {"align":"full","anchor":"zaly","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="zaly" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Залы</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Выберите зал</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_room","count":6} /--></div>
<!-- /wp:group -->
