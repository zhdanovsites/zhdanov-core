<?php
/**
 * Title: Готовая главная: туры, путешествия
 * Slug: zhdanov/page-home-tours
 * Categories: zhdanov-pages
 * Keywords: главная, туры, путешествия, турагентство, ретрит
 * Viewport Width: 1280
 * Description: Первый экран, туры, гиды, фото, отзывы, вопросы, подбор тура.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/tours"} /-->
<!-- wp:pattern {"slug":"zhdanov/quiz"} /-->
<!-- wp:pattern {"slug":"zhdanov/specialists"} /-->
<!-- wp:pattern {"slug":"zhdanov/gallery"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/faq"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
