<?php
/**
 * Title: Партнёры и площадки (логотипы)
 * Slug: zhdanov/partners
 * Categories: zhdanov-about,about
 * Keywords: партнёры, логотипы, клиенты, площадки, СМИ
 * Viewport Width: 1280
 * Description: Ряд логотипов: партнёры, площадки, СМИ о нас. Логотипы серые, при наведении цветные. Только с разрешения владельцев логотипов.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"align":"center","className":"is-style-zhdanov-eyebrow"} -->
<p class="has-text-align-center is-style-zhdanov-eyebrow">Партнёры</p>
<!-- /wp:paragraph -->
<!-- wp:gallery {"columns":5,"linkTo":"none","sizeSlug":"medium","className":"zh-logos","style":{"spacing":{"blockGap":{"top":"1.5rem","left":"2rem"}}}} -->
<figure class="wp-block-gallery has-nested-images columns-5 zh-logos"></figure>
<!-- /wp:gallery --></div>
<!-- /wp:group -->
