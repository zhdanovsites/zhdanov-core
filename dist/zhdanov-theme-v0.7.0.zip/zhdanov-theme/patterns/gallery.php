<?php
/**
 * Title: Галерея фото (вручную)
 * Slug: zhdanov/gallery
 * Categories: zhdanov-about,gallery
 * Keywords: галерея, фото
 * Viewport Width: 1280
 * Description: Сетка фотографий: добавьте снимки прямо на странице. Фото открываются крупно по клику.
 */
?>
<!-- wp:group {"align":"full","anchor":"galereya","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="galereya" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading">Галерея</h2>
<!-- /wp:heading -->
<!-- wp:gallery {"columns":3,"linkTo":"none","sizeSlug":"zhdanov-card","align":"wide","style":{"spacing":{"blockGap":{"top":"0.75rem","left":"0.75rem"}}}} -->
<figure class="wp-block-gallery alignwide has-nested-images columns-3 is-cropped"></figure>
<!-- /wp:gallery -->
</div>
<!-- /wp:group -->
