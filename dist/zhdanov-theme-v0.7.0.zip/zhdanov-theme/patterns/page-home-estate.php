<?php
/**
 * Title: Готовая главная: недвижимость, застройщик
 * Slug: zhdanov/page-home-estate
 * Categories: zhdanov-pages
 * Keywords: главная, недвижимость, застройщик, агентство, квартиры
 * Viewport Width: 1280
 * Description: Первый экран, объекты, калькулятор, о компании, документы, отзывы, заявка на просмотр.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/estate"} /-->
<!-- wp:pattern {"slug":"zhdanov/calc"} /-->
<!-- wp:pattern {"slug":"zhdanov/about"} /-->
<!-- wp:pattern {"slug":"zhdanov/docs"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
