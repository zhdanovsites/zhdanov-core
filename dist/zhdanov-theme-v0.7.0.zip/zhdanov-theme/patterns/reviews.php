<?php
/**
 * Title: Отзывы (из раздела «Отзывы»)
 * Slug: zhdanov/reviews
 * Categories: zhdanov-about,testimonials
 * Keywords: отзывы, мнения, клиенты
 * Viewport Width: 1280
 * Description: Настоящие отзывы карточками со ссылкой на оригинал. Данные из Консоль → Отзывы.
 */
?>
<!-- wp:group {"align":"full","anchor":"otzyvy","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="otzyvy" class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Отзывы</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Что говорят о нас</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_review","count":3} /-->
</div>
<!-- /wp:group -->
