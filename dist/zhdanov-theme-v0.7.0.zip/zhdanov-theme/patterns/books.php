<?php
/**
 * Title: Книги (из раздела «Книги»)
 * Slug: zhdanov/books
 * Categories: zhdanov-services
 * Keywords: книги, писатель, издательство, библиотека
 * Viewport Width: 1280
 * Description: Обложки книг; на странице книги аннотация, PDF/EPUB, где купить.
 */
?>
<!-- wp:group {"align":"full","anchor":"knigi","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="knigi" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Книги</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Мои книги</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_book","count":8} /--></div>
<!-- /wp:group -->
