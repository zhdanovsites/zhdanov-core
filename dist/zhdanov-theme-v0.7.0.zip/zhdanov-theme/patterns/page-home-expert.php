<?php
/**
 * Title: Готовая главная: эксперт, коуч, артист
 * Slug: zhdanov/page-home-expert
 * Categories: zhdanov-pages
 * Keywords: главная, коуч, эксперт, артист, психолог
 * Viewport Width: 1280
 * Block Types: core/post-content
 * Post Types: page
 * Description: Портрет и заголовок, о себе, вопросы, призыв, контакты.
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero-split"} /-->
<!-- wp:pattern {"slug":"zhdanov/about"} /-->
<!-- wp:pattern {"slug":"zhdanov/services"} /-->
<!-- wp:pattern {"slug":"zhdanov/quiz"} /-->
<!-- wp:pattern {"slug":"zhdanov/schedule"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/news-latest"} /-->
<!-- wp:pattern {"slug":"zhdanov/faq"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
