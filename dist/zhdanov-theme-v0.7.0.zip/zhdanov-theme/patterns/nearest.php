<?php
/**
 * Title: Ближайшие свободные окна (из «Расписания»)
 * Slug: zhdanov/nearest
 * Categories: zhdanov-services
 * Keywords: запись, окна, ближайшее время, слоты
 * Viewport Width: 1280
 * Description: Следующие свободные занятия или приёмы с кнопкой «Записаться».
 */
?>
<!-- wp:group {"align":"full","anchor":"zapis","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="zapis" class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Запись</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Ближайшее свободное время</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_class","layout":"nearest","count":4} /--></div>
<!-- /wp:group -->
