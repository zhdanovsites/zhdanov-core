<?php
/**
 * Title: Контакты: адрес, маршрут, мессенджеры
 * Slug: zhdanov/contacts
 * Categories: zhdanov-contacts
 * Keywords: контакты, адрес, карта, маршрут, телефон
 * Viewport Width: 1280
 * Description: Карточка адреса с кнопками «Маршрут» (Яндекс, 2ГИС, Google), карта по кнопке, телефон и мессенджеры. Данные берутся из «Жданов: настройки».
 */
?>
<!-- wp:group {"align":"full","anchor":"kontakty","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="kontakty" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading">Контакты</h2>
<!-- /wp:heading -->
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:zhdanov/contacts {"style":"buttons"} /--></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:zhdanov/route /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
