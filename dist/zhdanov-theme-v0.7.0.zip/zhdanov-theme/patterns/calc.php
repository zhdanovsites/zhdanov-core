<?php
/**
 * Title: Калькулятор стоимости
 * Slug: zhdanov/calc
 * Categories: zhdanov-services
 * Keywords: калькулятор, расчёт, стоимость, смета
 * Viewport Width: 1280
 * Description: Ползунки и формула: примерная цена и отправка расчёта.
 */
?>
<!-- wp:group {"align":"full","anchor":"raschet","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="raschet" class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Расчёт</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Сколько это будет стоить</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/calc /--></div>
<!-- /wp:group -->
