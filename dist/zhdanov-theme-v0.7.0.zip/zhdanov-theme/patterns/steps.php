<?php
/**
 * Title: Как мы работаем: шаги
 * Slug: zhdanov/steps
 * Categories: zhdanov-about
 * Keywords: шаги, этапы, как работаем
 * Viewport Width: 1280
 * Description: 4 шага от заявки до результата.
 */
?>
<!-- wp:group {"align":"full","anchor":"kak-rabotaem","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="kak-rabotaem" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading">Как мы работаем</h2>
<!-- /wp:heading -->
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30","top":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-zhdanov-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-zhdanov-card"><!-- wp:paragraph {"style":{"typography":{"fontSize":"2rem","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:2rem;font-weight:700;line-height:1">1</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Заявка</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">Оставляете заявку или пишете в мессенджер.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-zhdanov-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-zhdanov-card"><!-- wp:paragraph {"style":{"typography":{"fontSize":"2rem","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:2rem;font-weight:700;line-height:1">2</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Знакомство</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">Созваниваемся и уточняем задачу.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-zhdanov-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-zhdanov-card"><!-- wp:paragraph {"style":{"typography":{"fontSize":"2rem","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:2rem;font-weight:700;line-height:1">3</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Работа</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">Делаем, держим в курсе.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"is-style-zhdanov-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-zhdanov-card"><!-- wp:paragraph {"style":{"typography":{"fontSize":"2rem","lineHeight":"1","fontWeight":"700"}},"fontFamily":"heading","textColor":"accent"} -->
<p class="has-accent-color has-text-color has-heading-font-family" style="font-size:2rem;font-weight:700;line-height:1">4</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Результат</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">Сдаём и остаёмся на связи.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
