<?php
/**
 * Title: Готовая главная: фонд, храм, общественная организация
 * Slug: zhdanov/page-home-ngo
 * Categories: zhdanov-pages
 * Keywords: главная, фонд, храм, церковь, НКО, пожертвования
 * Viewport Width: 1280
 * Description: Первый экран, о нас, события и расписание, пожертвования, новости, документы, контакты.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/about"} /-->
<!-- wp:pattern {"slug":"zhdanov/events-upcoming"} /-->
<!-- wp:pattern {"slug":"zhdanov/donate"} /-->
<!-- wp:pattern {"slug":"zhdanov/news-latest"} /-->
<!-- wp:pattern {"slug":"zhdanov/docs"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
