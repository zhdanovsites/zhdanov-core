<?php
/**
 * Title: Специалисты (из раздела «Специалисты»)
 * Slug: zhdanov/specialists
 * Categories: zhdanov-services
 * Keywords: специалисты, врачи, мастера, преподаватели, команда
 * Viewport Width: 1280
 * Description: Карточки специалистов с записью к каждому. Данные из Консоль → Специалисты.
 */
?>
<!-- wp:group {"align":"full","anchor":"specialisty","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="specialisty" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Команда</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Кто будет с вами работать</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_person","count":6} /--></div>
<!-- /wp:group -->
