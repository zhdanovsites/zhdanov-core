<?php
/**
 * Title: Готовая главная: магазин, бренд
 * Slug: zhdanov/page-home-shop
 * Categories: zhdanov-pages
 * Keywords: главная, магазин, каталог, бренд
 * Viewport Width: 1280
 * Description: Первый экран, каталог, о бренде, отзывы, вопросы, заявка, контакты.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/catalog"} /-->
<!-- wp:pattern {"slug":"zhdanov/about"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/faq"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
