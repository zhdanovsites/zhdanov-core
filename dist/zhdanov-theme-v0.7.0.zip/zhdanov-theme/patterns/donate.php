<?php
/**
 * Title: Пожертвования
 * Slug: zhdanov/donate
 * Categories: zhdanov-services
 * Keywords: пожертвование, помощь, фонд, храм, поддержать
 * Viewport Width: 1280
 * Description: Выбор суммы и оплата онлайн (ЮKassa или Т-Банк).
 */
?>
<!-- wp:group {"align":"full","anchor":"pomoch","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="pomoch" class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Помочь</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Поддержите нас</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/gift {"title":"Ваше пожертвование","text":"Любая сумма помогает. Чек придёт на почту.","sums":"300, 500, 1000, 3000","mode":"donate"} /--></div>
<!-- /wp:group -->
