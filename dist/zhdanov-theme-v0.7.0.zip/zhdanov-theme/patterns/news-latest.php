<?php
/**
 * Title: Новости: последние записи
 * Slug: zhdanov/news-latest
 * Categories: zhdanov-news
 * Keywords: новости, блог, статьи
 * Viewport Width: 1280
 * Description: Три последние новости карточками и кнопка «Все новости».
 */
$zh_news_url = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' );
?>
<!-- wp:group {"align":"full","anchor":"novosti","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="novosti" class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Новости</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( $zh_news_url ); ?>">Все новости →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:query {"queryId":11,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","minimumColumnWidth":"17rem"},"style":{"spacing":{"blockGap":"var:preset|spacing|40"}}} -->
<!-- wp:group {"className":"zh-card","layout":{"type":"default"}} -->
<div class="wp-block-group zh-card"><!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2","sizeSlug":"zhdanov-card"} /-->
<!-- wp:post-date {"format":"j F Y"} /-->
<!-- wp:post-title {"level":3,"isLink":true} /-->
<!-- wp:post-excerpt {"excerptLength":20} /--></div>
<!-- /wp:group -->
<!-- /wp:post-template --></div>
<!-- /wp:query --></div>
<!-- /wp:group -->
