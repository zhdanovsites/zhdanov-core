<?php
/**
 * Title: Квиз «Подобрать программу»
 * Slug: zhdanov/quiz
 * Categories: zhdanov-services
 * Keywords: квиз, опрос, подбор, тест, заявка
 * Viewport Width: 1280
 * Description: 3 вопроса по одному на экране, в конце имя и телефон. Ответы приходят в заявке. Вопросы меняются в настройках блока справа.
 */
?>
<!-- wp:group {"align":"full","anchor":"podbor","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="podbor" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:zhdanov/quiz /--></div>
<!-- /wp:group -->
