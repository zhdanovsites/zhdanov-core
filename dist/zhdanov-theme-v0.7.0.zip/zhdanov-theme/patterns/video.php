<?php
/**
 * Title: Видео (загрузка по клику)
 * Slug: zhdanov/video
 * Categories: zhdanov-about,media
 * Keywords: видео, клип, youtube, rutube, vk
 * Viewport Width: 1280
 * Description: Заголовок и видео YouTube, Rutube или VK. Плеер грузится только по нажатию: страница остаётся быстрой.
 */
?>
<!-- wp:group {"align":"full","anchor":"video","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"960px"}} -->
<div id="video" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading">Видео</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/video {"title":"Название видео"} /--></div>
<!-- /wp:group -->
