<?php
/**
 * Title: Готовая главная: фотостудия, залы, коворкинг
 * Slug: zhdanov/page-home-rooms
 * Categories: zhdanov-pages
 * Keywords: главная, фотостудия, залы, аренда, коворкинг
 * Viewport Width: 1280
 * Description: Первый экран, залы, услуги, работы, сертификат, отзывы, бронь.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/rooms"} /-->
<!-- wp:pattern {"slug":"zhdanov/services"} /-->
<!-- wp:pattern {"slug":"zhdanov/gallery"} /-->
<!-- wp:pattern {"slug":"zhdanov/gift"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/faq"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
