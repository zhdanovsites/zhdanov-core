<?php
/**
 * Title: Документы (из раздела «Документы»)
 * Slug: zhdanov/docs
 * Categories: zhdanov-services
 * Keywords: документы, лицензии, устав, отчёты
 * Viewport Width: 1280
 * Description: Файлы PDF по группам: лицензии, уставы, отчёты, договоры.
 */
?>
<!-- wp:group {"align":"full","anchor":"dokumenty","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="dokumenty" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Документы</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Лицензии и документы</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_doc","count":50,"showMoreLink":false} /--></div>
<!-- /wp:group -->
