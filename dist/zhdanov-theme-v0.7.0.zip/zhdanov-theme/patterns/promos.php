<?php
/**
 * Title: Акции (из раздела «Акции»)
 * Slug: zhdanov/promos
 * Categories: zhdanov-services
 * Keywords: акции, скидки, спецпредложения
 * Viewport Width: 1280
 * Description: Действующие акции с таймером, закончившиеся скрываются сами.
 */
?>
<!-- wp:group {"align":"full","anchor":"akcii","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="akcii" class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Акции</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Сейчас выгодно</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_promo","count":3} /--></div>
<!-- /wp:group -->
