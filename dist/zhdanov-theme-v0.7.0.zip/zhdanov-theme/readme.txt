=== Тема Жданов ===
Contributors: zhdanovsites
Requires at least: 6.7
Tested up to: 6.8
Requires PHP: 7.4
Version: 0.7.0
License: GPLv2 or later

Универсальная блочная тема Zhdanov Sites. Внешний вид: палитры (светлая, тёмная, тёплая, яркая), шрифты на сервере (Cormorant Garamond, Manrope, Unbounded), 50+ паттернов и готовые главные для 14 ниш. Работает в паре с плагином «Жданов: ядро».

Стандарты: 360 px без прокрутки вбок, Lighthouse телефон 95+, доступность WCAG AA, без Google Fonts.
