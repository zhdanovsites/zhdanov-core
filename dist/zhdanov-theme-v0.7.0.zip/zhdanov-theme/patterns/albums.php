<?php
/**
 * Title: Альбомы (из раздела «Альбомы»)
 * Slug: zhdanov/albums
 * Categories: zhdanov-about,gallery
 * Keywords: галерея, фото, альбомы
 * Viewport Width: 1280
 * Description: Плитка фотоальбомов. Данные из Консоль → Альбомы.
 */
?>
<!-- wp:group {"align":"full","anchor":"foto","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="foto" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading">Фото</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_album","count":6} /-->
</div>
<!-- /wp:group -->
