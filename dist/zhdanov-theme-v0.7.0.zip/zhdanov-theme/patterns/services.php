<?php
/**
 * Title: Услуги и цены (из раздела «Услуги»)
 * Slug: zhdanov/services
 * Categories: zhdanov-services
 * Keywords: услуги, цены, прайс, запись
 * Viewport Width: 1280
 * Description: Список услуг с ценами и кнопкой «Записаться». Данные из Консоль → Услуги.
 */
?>
<!-- wp:group {"align":"full","anchor":"uslugi","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="uslugi" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Услуги</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Услуги и цены</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_service","count":8} /-->
</div>
<!-- /wp:group -->
