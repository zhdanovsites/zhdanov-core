<?php
/**
 * Title: Призыв к действию
 * Slug: zhdanov/cta
 * Categories: zhdanov-cta, call-to-action
 * Keywords: призыв, запись, заявка, кнопка
 * Viewport Width: 1280
 * Description: Яркая полоса с заголовком и кнопкой записи.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}},"elements":{"link":{"color":{"text":"var:preset|color|accent-contrast"}}}},"backgroundColor":"accent","textColor":"accent-contrast","layout":{"type":"constrained","contentSize":"860px"}} -->
<div class="wp-block-group alignfull has-accent-contrast-color has-accent-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading {"textAlign":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|accent-contrast"}}}},"textColor":"accent-contrast"} -->
<h2 class="wp-block-heading has-text-align-center has-accent-contrast-color has-text-color has-link-color">Готовы начать? Напишите нам сегодня</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Ответим в течение рабочего дня и подскажем, с чего начать.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"base","textColor":"contrast"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-contrast-color has-base-background-color has-text-color has-background wp-element-button" href="#kontakty">Записаться</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
