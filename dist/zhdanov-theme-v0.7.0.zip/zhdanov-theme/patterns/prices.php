<?php
/**
 * Title: Прайс-лист таблицей (вручную)
 * Slug: zhdanov/prices
 * Categories: zhdanov-services
 * Keywords: прайс, цены, таблица
 * Viewport Width: 1280
 * Description: Простая таблица цен, правится прямо на странице. Для сайтов без раздела «Услуги».
 */
?>
<!-- wp:group {"align":"full","anchor":"ceny","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"860px"}} -->
<div id="ceny" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading">Цены</h2>
<!-- /wp:heading -->
<!-- wp:table {"hasFixedLayout":false,"className":"zh-price-table"} -->
<figure class="wp-block-table zh-price-table"><table><thead><tr><th>Услуга</th><th>Время</th><th>Цена</th></tr></thead><tbody><tr><td>Первая консультация</td><td>30 мин</td><td>Бесплатно</td></tr><tr><td>Основная услуга</td><td>60 мин</td><td>3 000 ₽</td></tr><tr><td>Пакет из 5 занятий</td><td>5 × 60 мин</td><td>13 500 ₽</td></tr></tbody></table></figure>
<!-- /wp:table -->
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color">Цены указаны на сегодня. Точную стоимость подтвердим при записи.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
