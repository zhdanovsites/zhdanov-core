<?php
/**
 * Тема Жданов: функции темы.
 * Всё оформление в theme.json, здесь только подключения и мелкие улучшения скорости.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ZHDANOV_THEME_VERSION', '0.3.0' );

add_action( 'after_setup_theme', function () {
	// WooCommerce: тема совместима (галерея товара с увеличением и листанием).
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	load_theme_textdomain( 'zhdanov', get_template_directory() . '/languages' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );
	add_theme_support( 'responsive-embeds' );
	// Обложка записи 1200×630 для превью в мессенджерах (og:image).
	add_image_size( 'zhdanov-og', 1200, 630, true );
	add_image_size( 'zhdanov-card', 720, 480, true );
} );

/* Маленький CSS поверх theme.json: меню на телефоне, карточки, доступность. */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'zhdanov-theme', get_template_directory_uri() . '/assets/css/theme.css', array(), ZHDANOV_THEME_VERSION );
} );

/* Предзагрузка основного шрифта текста (кириллица): быстрее первый экран. */
add_action( 'wp_head', function () {
	printf(
		'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
		esc_url( get_template_directory_uri() . '/assets/fonts/manrope-cyrillic-wght-normal.woff2' )
	);
}, 1 );

/* Убираем то, что тормозит и не нужно: эмодзи-скрипт, лишние ссылки в head. */
add_action( 'init', function () {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
} );

/* Разделы паттернов: так клиенту проще найти нужный блок. */
add_action( 'init', function () {
	$cats = array(
		'zhdanov-hero'     => 'Жданов: первый экран',
		'zhdanov-about'    => 'Жданов: о нас',
		'zhdanov-services' => 'Жданов: услуги и цены',
		'zhdanov-events'   => 'Жданов: афиша',
		'zhdanov-news'     => 'Жданов: новости',
		'zhdanov-cta'      => 'Жданов: призыв',
		'zhdanov-faq'      => 'Жданов: вопросы',
		'zhdanov-contacts' => 'Жданов: контакты',
		'zhdanov-pages'    => 'Жданов: готовые страницы',
	);
	foreach ( $cats as $slug => $label ) {
		register_block_pattern_category( $slug, array( 'label' => $label ) );
	}

	// Стили блоков: выбираются в редакторе кликом.
	register_block_style( 'core/group', array( 'name' => 'zhdanov-card', 'label' => 'Карточка' ) );
	register_block_style( 'core/group', array( 'name' => 'zhdanov-band', 'label' => 'Полоса фона' ) );
	register_block_style( 'core/paragraph', array( 'name' => 'zhdanov-eyebrow', 'label' => 'Надзаголовок' ) );
	register_block_style( 'core/list', array( 'name' => 'zhdanov-checks', 'label' => 'Галочки' ) );
} );

/* Ссылка «Перейти к содержимому» для клавиатуры есть в ядре WP для блочных тем. */

/* Длина анонса в карточках. */
add_filter( 'excerpt_length', function () {
	return 24;
} );
add_filter( 'excerpt_more', function () {
	return '…';
} );

/**
 * При включении темы: если меню ещё нет, создаём «Главное меню» из страниц сайта.
 * Существующие меню (в том числе старые классические) не трогаем.
 */
function zhdanov_theme_create_menu() {
	$menus   = get_posts( array( 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'numberposts' => -1 ) );
	$replace = 0;
	foreach ( $menus as $m ) {
		// Заглушка WordPress (только «список страниц») не считается настоящим меню.
		if ( '<!-- wp:page-list /-->' === trim( $m->post_content ) ) {
			$replace = $m->ID;
			continue;
		}
		return;
	}
	if ( wp_get_nav_menus() ) {
		return;
	}
	$links = array();
	$front = (int) get_option( 'page_on_front' );
	$blog  = (int) get_option( 'page_for_posts' );
	$pages = get_pages( array( 'sort_column' => 'menu_order,post_title', 'parent' => 0, 'number' => 7 ) );
	foreach ( $pages as $p ) {
		if ( $p->ID === $front || $p->ID === (int) get_option( 'wp_page_for_privacy_policy' ) ) {
			continue;
		}
		$links[] = array( $p->post_title, get_permalink( $p ), $p->ID, 'page' );
	}
	if ( post_type_exists( 'zh_event' ) ) {
		array_unshift( $links, array( 'Афиша', get_post_type_archive_link( 'zh_event' ), 0, 'custom' ) );
	}
	if ( ! $links ) {
		return;
	}
	$content = '';
	foreach ( array_slice( $links, 0, 6 ) as $l ) {
		$attrs = array( 'label' => $l[0], 'url' => $l[1], 'kind' => 'page' === $l[3] ? 'post-type' : 'custom', 'isTopLevelLink' => true );
		if ( $l[2] ) {
			$attrs['type'] = 'page';
			$attrs['id']   = $l[2];
		}
		$content .= '<!-- wp:navigation-link ' . wp_json_encode( $attrs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ' /-->';
	}
	$data = array( 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'post_title' => 'Главное меню', 'post_content' => $content );
	if ( $replace ) {
		$data['ID'] = $replace;
		wp_update_post( $data );
	} else {
		wp_insert_post( $data );
	}
}
add_action( 'after_switch_theme', 'zhdanov_theme_create_menu' );
