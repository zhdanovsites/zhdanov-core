<?php
/**
 * Title: Вопросы и ответы (FAQ)
 * Slug: zhdanov/faq
 * Categories: zhdanov-faq
 * Keywords: faq, вопросы, ответы
 * Viewport Width: 1280
 * Description: Раскрывающиеся вопросы. Разметка FAQPage для поиска добавляется автоматически.
 */
?>
<!-- wp:group {"align":"full","anchor":"voprosy","className":"zh-faq","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"820px"}} -->
<div id="voprosy" class="wp-block-group alignfull zh-faq" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading -->
<h2 class="wp-block-heading">Частые вопросы</h2>
<!-- /wp:heading -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Сколько это стоит?</summary><!-- wp:paragraph -->
<p>Короткий честный ответ с ценой или диапазоном.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Как записаться?</summary><!-- wp:paragraph -->
<p>Позвоните или напишите в мессенджер, кнопки внизу страницы.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Где вы находитесь?</summary><!-- wp:paragraph -->
<p>Адрес и как добраться: в разделе «Контакты», там же кнопки маршрута.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group -->
