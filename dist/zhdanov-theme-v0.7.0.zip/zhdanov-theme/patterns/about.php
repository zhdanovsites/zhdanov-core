<?php
/**
 * Title: О нас / об авторе
 * Slug: zhdanov/about
 * Categories: zhdanov-about
 * Keywords: о нас, об авторе, история
 * Viewport Width: 1280
 * Description: Фото слева, текст и факты справа.
 */
?>
<!-- wp:group {"align":"full","anchor":"o-nas","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="o-nas" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:media-text {"mediaType":"image","mediaWidth":42,"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|40"}}} -->
<div class="wp-block-media-text is-stacked-on-mobile is-vertically-aligned-center" style="grid-template-columns:42% auto"><figure class="wp-block-media-text__media"></figure><div class="wp-block-media-text__content"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">О нас</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Кто мы и почему нам доверяют</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Два-три предложения о вас: с чего начинали, что делаете сейчас, чем отличаетесь. Пишите фактами, которые можно проверить.</p>
<!-- /wp:paragraph -->
<!-- wp:list {"className":"is-style-zhdanov-checks"} -->
<ul class="wp-block-list is-style-zhdanov-checks"><!-- wp:list-item -->
<li>Факт: лет работы или число клиентов</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Факт: образование, награды, площадки</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Факт: чем вы отличаетесь от других</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:media-text --></div>
<!-- /wp:group -->
