<?php
/**
 * Title: Лента Telegram-канала
 * Slug: zhdanov/tgfeed
 * Categories: zhdanov-services
 * Keywords: telegram, канал, новости, подписка
 * Viewport Width: 1280
 * Description: Последние посты канала и кнопка «Подписаться».
 */
?>
<!-- wp:group {"align":"full","anchor":"telegram","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="telegram" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Telegram</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Свежее в канале</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/tgfeed {"title":""} /--></div>
<!-- /wp:group -->
