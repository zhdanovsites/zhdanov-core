<?php
/**
 * Title: Подарочный сертификат
 * Slug: zhdanov/gift
 * Categories: zhdanov-services
 * Keywords: сертификат, подарок, подарочная карта
 * Viewport Width: 1280
 * Description: Выбор суммы и оплата онлайн, код приходит на почту. Без оплаты: заказ через мессенджер.
 */
?>
<!-- wp:group {"align":"full","anchor":"sertifikat","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"base-2","layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="sertifikat" class="wp-block-group alignfull has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Подарок</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Подарите сертификат</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/gift {"title":"Подарочный сертификат"} /--></div>
<!-- /wp:group -->
