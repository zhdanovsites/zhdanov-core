<?php
/**
 * Title: Туры (из раздела «Туры»)
 * Slug: zhdanov/tours
 * Categories: zhdanov-services
 * Keywords: туры, путешествия, ретриты, поездки
 * Viewport Width: 1280
 * Description: Карточки туров с ближайшей датой заезда и ценой.
 */
?>
<!-- wp:group {"align":"full","anchor":"tury","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="tury" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Туры</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Куда поедем</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_tour","count":6} /--></div>
<!-- /wp:group -->
