<?php
/**
 * Title: Расписание и запись (из раздела «Расписание»)
 * Slug: zhdanov/schedule
 * Categories: zhdanov-services
 * Keywords: расписание, запись, занятия, приём, слоты
 * Viewport Width: 1280
 * Description: Занятия и приёмы по дням недели, кнопка «Записаться» с готовым текстом. Данные из Консоль → Расписание.
 */
?>
<!-- wp:group {"align":"full","anchor":"raspisanie","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="raspisanie" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Расписание</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Выберите удобное время</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_class","showMoreLink":false} /--></div>
<!-- /wp:group -->
