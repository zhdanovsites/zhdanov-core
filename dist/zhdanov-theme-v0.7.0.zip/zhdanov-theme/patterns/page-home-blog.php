<?php
/**
 * Title: Готовая главная: блог, медиа, архив
 * Slug: zhdanov/page-home-blog
 * Categories: zhdanov-pages
 * Keywords: главная, блог, архив, медиа, автор
 * Viewport Width: 1280
 * Description: Автор, последние записи, альбомы, подписка через заявку.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero-split"} /-->
<!-- wp:pattern {"slug":"zhdanov/news-latest"} /-->
<!-- wp:pattern {"slug":"zhdanov/albums"} /-->
<!-- wp:pattern {"slug":"zhdanov/about"} /-->
<!-- wp:pattern {"slug":"zhdanov/cta"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
