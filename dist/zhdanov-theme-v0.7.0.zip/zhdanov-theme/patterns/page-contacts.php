<?php
/**
 * Title: Готовая страница: Контакты
 * Slug: zhdanov/page-contacts
 * Categories: zhdanov-pages
 * Keywords: контакты, адрес, карта
 * Viewport Width: 1280
 * Description: Контакты, маршрут, карта по кнопке и форма заявки.
 * Post Types: page
 */
?>
<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40","top":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:zhdanov/contacts {"style":"buttons"} /--></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:zhdanov/route /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
