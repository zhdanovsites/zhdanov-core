<?php
/**
 * Title: Готовая главная: услуги (салон, школа, клиника)
 * Slug: zhdanov/page-home-services
 * Categories: zhdanov-pages
 * Keywords: главная, услуги, салон, школа, клиника
 * Viewport Width: 1280
 * Description: Первый экран, услуги и цены, цифры, команда, отзывы, вопросы, заявка, контакты.
 * Block Types: core/post-content
 * Post Types: page
 */
?>
<!-- wp:pattern {"slug":"zhdanov/hero"} /-->
<!-- wp:pattern {"slug":"zhdanov/services"} /-->
<!-- wp:pattern {"slug":"zhdanov/nearest"} /-->
<!-- wp:pattern {"slug":"zhdanov/specialists"} /-->
<!-- wp:pattern {"slug":"zhdanov/promos"} /-->
<!-- wp:pattern {"slug":"zhdanov/numbers"} /-->
<!-- wp:pattern {"slug":"zhdanov/reviews"} /-->
<!-- wp:pattern {"slug":"zhdanov/faq"} /-->
<!-- wp:pattern {"slug":"zhdanov/form"} /-->
<!-- wp:pattern {"slug":"zhdanov/contacts"} /-->
