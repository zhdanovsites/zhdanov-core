<?php
/**
 * Title: Филиалы (из раздела «Филиалы»)
 * Slug: zhdanov/branches
 * Categories: zhdanov-services
 * Keywords: филиалы, адреса, часы работы, карта
 * Viewport Width: 1280
 * Description: Адреса, часы, «Открыто сейчас», маршрут, все точки на карте.
 */
?>
<!-- wp:group {"align":"full","anchor":"filialy","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<div id="filialy" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"className":"is-style-zhdanov-eyebrow"} -->
<p class="is-style-zhdanov-eyebrow">Адреса</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Где нас найти</h2>
<!-- /wp:heading -->
<!-- wp:zhdanov/collection {"type":"zh_branch","showMoreLink":false} /--></div>
<!-- /wp:group -->
